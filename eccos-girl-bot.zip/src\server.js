// src/server.js — Express Web Server with Discord OAuth Gate & Whitelist
const express = require('express');
const session = require('express-session');
const path = require('path');
const { fetchExploitStatuses, setExploitOverride, clearExploitOverride, TRACKED } = require('./status');
const { readData, writeData } = require('./database/db');
const { getEmojiRules, setEmojiRules, syncStatusChannels } = require('./status-channels');
const { getWhitelistedUsers, isWhitelisted, addWhitelist, removeWhitelist } = require('./whitelist');
const { getClient } = require('./bot');
const { EmbedBuilder } = require('discord.js');

const app = express();
app.set('trust proxy', 1);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: process.env.SESSION_SECRET || 'eccos-girl-secret-change-me',
    resave: true,
    saveUninitialized: true,
    proxy: true,
    cookie: {
        secure: false, // Compatible across HTTP and HTTPS proxies
        sameSite: 'lax',
        maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    }
}));

function getRedirectUri(req) {
    if (process.env.REDIRECT_URI) return process.env.REDIRECT_URI;
    const host = req.get('host');
    const protocol = host.includes('localhost') ? 'http' : 'https';
    return `${protocol}://${host}/auth/discord/callback`;
}

// ── Middleware: Discord OAuth & Whitelist Gate ─────────────────────
function requireDiscordAuth(req, res, next) {
    const exempt = [
        '/login.html',
        '/access-denied.html',
        '/auth/discord',
        '/auth/discord/callback',
        '/api/me',
        '/invite',
        '/pfp.jpg',
        '/style.css'
    ];

    if (exempt.some(e => req.path.startsWith(e))) return next();

    // Check if logged in with Discord
    if (!req.session.discordUser) {
        if (req.path.startsWith('/api/')) {
            return res.status(401).json({ ok: false, error: 'Unauthorized' });
        }
        return res.redirect('/login.html');
    }

    const userId = req.session.discordUser.id;

    // Auto-whitelist first user if whitelist is empty
    const currentWl = getWhitelistedUsers();
    if (currentWl.length === 0) {
        addWhitelist(userId);
    }

    // Check whitelist status
    if (!isWhitelisted(userId)) {
        if (req.path.startsWith('/api/')) {
            return res.status(403).json({ ok: false, error: 'Forbidden: Not Whitelisted' });
        }
        return res.sendFile(path.join(__dirname, '../public/access-denied.html'));
    }

    next();
}

app.use(requireDiscordAuth);
app.use(express.static(path.join(__dirname, '../public')));

// ── API: User & Auth Status ─────────────────────────────────────────
app.get('/api/me', (req, res) => {
    const user = req.session.discordUser || null;
    const whitelisted = user ? isWhitelisted(user.id) : false;
    res.json({
        authenticated: !!user,
        whitelisted,
        discordUser: user
    });
});

// ── API: software status ───────────────────────────────────────────
app.get('/api/status', async (req, res) => {
    try {
        const statuses = await fetchExploitStatuses();
        res.json({ ok: true, data: statuses });
    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});

// ── API: Whitelist Management ─────────────────────────────────────
app.get('/api/dashboard/whitelist', (req, res) => {
    res.json({ ok: true, whitelist: getWhitelistedUsers() });
});

app.post('/api/dashboard/whitelist', (req, res) => {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ ok: false, error: 'Missing userId' });
    addWhitelist(userId);
    res.json({ ok: true, whitelist: getWhitelistedUsers() });
});

app.delete('/api/dashboard/whitelist', (req, res) => {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ ok: false, error: 'Missing userId' });
    removeWhitelist(userId);
    res.json({ ok: true, whitelist: getWhitelistedUsers() });
});

// ── API: Dashboard stats & control ────────────────────────────────
app.get('/api/dashboard/stats', async (req, res) => {
    const client = getClient();
    const isOnline = client && client.isReady();
    const statuses = await fetchExploitStatuses();

    res.json({
        ok: true,
        botStatus: isOnline ? 'online' : 'offline',
        botTag: isOnline ? client.user.tag : 'Not connected',
        guildsCount: isOnline ? client.guilds.cache.size : 0,
        uptimeSeconds: isOnline ? Math.floor(client.uptime / 1000) : 0,
        memoryMb: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2),
        statuses
    });
});

app.post('/api/dashboard/override', async (req, res) => {
    const { executor, statusType, note } = req.body;
    if (!executor) return res.status(400).json({ ok: false, error: 'Missing executor' });

    if (statusType === 'reset') {
        clearExploitOverride(executor);
    } else {
        let status = 'online';
        let detected = false;
        let bypassing = false;

        if (statusType === 'online') { status = 'online'; detected = false; bypassing = false; }
        else if (statusType === 'bypassing') { status = 'online'; detected = true; bypassing = true; }
        else if (statusType === 'detected') { status = 'online'; detected = true; bypassing = false; }
        else if (statusType === 'partial') { status = 'partial'; detected = false; bypassing = false; }
        else if (statusType === 'offline') { status = 'offline'; detected = false; bypassing = false; }

        setExploitOverride(executor, { status, detected, bypassing, note: note || 'Updated & Working' });
    }

    const client = getClient();
    if (client) await syncStatusChannels(client, true);

    res.json({ ok: true, statuses: await fetchExploitStatuses() });
});

app.post('/api/dashboard/announce', async (req, res) => {
    const { title, message } = req.body;
    if (!title || !message) return res.status(400).json({ ok: false, error: 'Title and message required' });

    const client = getClient();
    if (!client || !client.isReady()) return res.status(503).json({ ok: false, error: 'Bot is offline' });

    const user = req.session.discordUser;
    const embed = new EmbedBuilder()
        .setAuthor({ name: `Dashboard Broadcast by ${user.username}`, iconURL: user.avatar })
        .setTitle(`📢 ${title}`)
        .setDescription(message)
        .setColor(0xc467ff)
        .setTimestamp();

    let sent = 0;
    for (const guild of client.guilds.cache.values()) {
        const textChannel = guild.channels.cache.find(c => c.isTextBased() && c.permissionsFor(guild.members.me).has('SendMessages'));
        if (textChannel) {
            try {
                await textChannel.send({ embeds: [embed] });
                sent++;
            } catch {}
        }
    }

    res.json({ ok: true, sentCount: sent });
});

app.post('/api/dashboard/emojis', (req, res) => {
    const { guildId, rules } = req.body;
    if (!rules) return res.status(400).json({ ok: false, error: 'Missing rules' });
    
    setEmojiRules(guildId || 'default', rules);
    const client = getClient();
    if (client) syncStatusChannels(client, true);

    res.json({ ok: true, rules: getEmojiRules(guildId || 'default') });
});

app.post('/api/dashboard/sync', async (req, res) => {
    const client = getClient();
    if (!client || !client.isReady()) {
        return res.status(503).json({ ok: false, error: 'Bot is not connected' });
    }
    await syncStatusChannels(client, true);
    res.json({ ok: true });
});

// ── Discord OAuth2 ─────────────────────────────────────────────────
app.get('/auth/discord', (req, res) => {
    if (!process.env.DISCORD_CLIENT_ID || process.env.DISCORD_CLIENT_ID === 'your_application_id_here') {
        return res.status(503).send('Discord OAuth not configured yet.');
    }

    const redirectUri = getRedirectUri(req);
    const params = new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        redirect_uri: redirectUri,
        response_type: 'code',
        scope: 'identify',
    });

    res.redirect(`https://discord.com/api/oauth2/authorize?${params}`);
});

app.get('/auth/discord/callback', async (req, res) => {
    const { code } = req.query;
    if (!code) return res.redirect('/login.html?error=no_code');

    try {
        const redirectUri = getRedirectUri(req);
        const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                client_id: process.env.DISCORD_CLIENT_ID,
                client_secret: process.env.DISCORD_CLIENT_SECRET,
                grant_type: 'authorization_code',
                code,
                redirect_uri: redirectUri,
            })
        });

        const tokenData = await tokenRes.json();
        if (!tokenData.access_token) {
            console.error('[OAuth] Token error response:', tokenData);
            throw new Error(tokenData.error_description || 'No access token returned');
        }

        const userRes = await fetch('https://discord.com/api/users/@me', {
            headers: { Authorization: `Bearer ${tokenData.access_token}` }
        });
        const user = await userRes.json();

        req.session.discordUser = {
            id: user.id,
            username: user.username,
            discriminator: user.discriminator,
            avatar: user.avatar
                ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
                : `https://cdn.discordapp.com/embed/avatars/${(BigInt(user.id) >> 22n) % 6n}.png`,
        };

        const whitelisted = isWhitelisted(user.id);
        if (!whitelisted) {
            const currentWl = getWhitelistedUsers();
            if (currentWl.length === 0) {
                addWhitelist(user.id);
            }
        }

        req.session.save((err) => {
            if (err) console.error('[OAuth] Session save error:', err);
            if (isWhitelisted(user.id)) {
                res.redirect('/dashboard');
            } else {
                res.redirect('/access-denied.html');
            }
        });
    } catch (err) {
        console.error('[OAuth]', err);
        res.redirect('/login.html?error=oauth_failed');
    }
});

// ── Logout ──────────────────────────────────────────────────────────
app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ ok: true });
});

// ── Dedicated /dashboard route ──────────────────────────────────────
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/dashboard.html'));
});

// ── Invite link ────────────────────────────────────────────────────
app.get('/invite', (req, res) => {
    const clientId = process.env.DISCORD_CLIENT_ID;
    if (!clientId) return res.status(503).send('Invite not configured.');
    const params = new URLSearchParams({
        client_id: clientId,
        permissions: '8',
        scope: 'bot applications.commands'
    });
    res.redirect(`https://discord.com/api/oauth2/authorize?${params}`);
});

// ── Catch-all ───────────────────────────────────────────────────────
app.get('*', (req, res) => {
    if (req.session.discordUser && isWhitelisted(req.session.discordUser.id)) {
        res.sendFile(path.join(__dirname, '../public/index.html'));
    } else if (req.session.discordUser) {
        res.sendFile(path.join(__dirname, '../public/access-denied.html'));
    } else {
        res.redirect('/login.html');
    }
});

setInterval(() => {
    const selfUrl = process.env.RENDER_EXTERNAL_URL || 'https://eccos-girl-bot.onrender.com/api/status';
    fetch(selfUrl).catch(() => {});
}, 4 * 60 * 1000);

function startServer() {
    return new Promise(resolve => {
        const port = process.env.PORT || 3000;
        app.listen(port, () => {
            console.log(`[Web] Listening on port ${port}`);
            resolve();
        });
    });
}

module.exports = { startServer };
